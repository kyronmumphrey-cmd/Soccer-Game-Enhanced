import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-23ffdfef/health", (c) => {
  return c.json({ status: "ok" });
});

type PartyMember = { id: string; name: string; joinedAt: number; lastSeen: number };
type Party = { code: string; hostId: string; members: PartyMember[]; started: boolean; createdAt: number };

const partyKey = (code: string) => `game-day:party:${code.toUpperCase()}`;
const cleanCode = (value: string) => value.replace(/[^A-Z0-9]/gi, "").toUpperCase().slice(0, 6);
const cleanName = (value: string) => value.trim().slice(0, 16) || "Player";
const activeMembers = (party: Party) => party.members.filter((member) => Date.now() - member.lastSeen < 45_000);

app.post("/make-server-23ffdfef/parties", async (c) => {
  const { playerId, name } = await c.req.json();
  if (!playerId) return c.json({ error: "A player ID is required." }, 400);
  for (let attempt = 0; attempt < 5; attempt++) {
    const code = crypto.randomUUID().replace(/-/g, "").slice(0, 6).toUpperCase();
    if (await kv.get(partyKey(code))) continue;
    const now = Date.now();
    const party: Party = { code, hostId: playerId, members: [{ id: playerId, name: cleanName(name), joinedAt: now, lastSeen: now }], started: false, createdAt: now };
    await kv.set(partyKey(code), party);
    return c.json({ party });
  }
  return c.json({ error: "Could not create a party. Please try again." }, 500);
});

app.post("/make-server-23ffdfef/parties/:code/join", async (c) => {
  const code = cleanCode(c.req.param("code"));
  const { playerId, name } = await c.req.json();
  const party = await kv.get(partyKey(code)) as Party | null;
  if (!party) return c.json({ error: "Party not found." }, 404);
  if (!playerId) return c.json({ error: "A player ID is required." }, 400);
  const now = Date.now();
  const member = party.members.find((item) => item.id === playerId);
  if (member) { member.lastSeen = now; member.name = cleanName(name); }
  else if (activeMembers(party).length >= 2) return c.json({ error: "This party is full." }, 409);
  else party.members.push({ id: playerId, name: cleanName(name), joinedAt: now, lastSeen: now });
  party.members = activeMembers(party);
  await kv.set(partyKey(code), party);
  return c.json({ party });
});

app.post("/make-server-23ffdfef/parties/:code/heartbeat", async (c) => {
  const code = cleanCode(c.req.param("code"));
  const { playerId } = await c.req.json();
  const party = await kv.get(partyKey(code)) as Party | null;
  if (!party) return c.json({ error: "Party not found." }, 404);
  const member = party.members.find((item) => item.id === playerId);
  if (!member) return c.json({ error: "You are not in this party." }, 403);
  member.lastSeen = Date.now();
  party.members = activeMembers(party);
  await kv.set(partyKey(code), party);
  return c.json({ party });
});

app.post("/make-server-23ffdfef/parties/:code/start", async (c) => {
  const code = cleanCode(c.req.param("code"));
  const { playerId } = await c.req.json();
  const party = await kv.get(partyKey(code)) as Party | null;
  if (!party) return c.json({ error: "Party not found." }, 404);
  if (party.hostId !== playerId) return c.json({ error: "Only the host can start the match." }, 403);
  if (activeMembers(party).length < 2) return c.json({ error: "Waiting for one more player." }, 400);
  party.started = true;
  await kv.set(partyKey(code), party);
  return c.json({ party });
});

Deno.serve(app.fetch);
