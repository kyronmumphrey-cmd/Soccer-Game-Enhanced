import { useEffect, useRef, useState, useCallback } from "react"
import { projectId, publicAnonKey } from "../utils/supabase/info"

type Screen = "home" | "game"
type Difficulty = "rookie" | "pro" | "legend"
type MatchFormat = "1v1" | "11v11"
type PartyMember = { id: string; name: string }
type Party = { code: string; hostId: string; members: PartyMember[]; started: boolean }

const PARTY_API = `https://${projectId}.supabase.co/functions/v1/make-server-23ffdfef`

async function partyRequest(path: string, method: "GET" | "POST" = "POST", body?: unknown) {
  const response = await fetch(`${PARTY_API}${path}`, {
    method,
    headers: { Authorization: `Bearer ${publicAnonKey}`, "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  })
  const data = await response.json()
  if (!response.ok) throw new Error(data.error || "Party service unavailable.")
  return data as { party: Party }
}

const W = 1320
const H = 760
const PLAYER_R = 16
const BALL_R = 10
const GOAL_H = 170
const GOAL_DEPTH = 56
const FRICTION = 0.88
const BALL_FRICTION = 0.985
const PLAYER_SPEED = 4.2
const CPU_SPEED = 3.0
const KICK_FORCE = 11
const DRIBBLE_DIST = PLAYER_R + BALL_R + 4
const SHOOT_SPEED = 7
const GOALIE_SPEED = 2.35
const GOALIE_R = 12
const SLIDE_FRAMES = 13
const SLIDE_COOLDOWN = 40
const SLIDE_SPEED = 7.4

const DIFFICULTIES: Record<Difficulty, {
  label: string
  caption: string
  cpuSpeed: number
  cpuShotRange: number
  cpuAim: number
  goalieSpeed: number
  goalieRead: number
  goalieReach: number
}> = {
  rookie: { label: "Rookie", caption: "A relaxed first kickabout", cpuSpeed: 2.6, cpuShotRange: 380, cpuAim: 78, goalieSpeed: 1.7, goalieRead: 0.02, goalieReach: 0 },
  pro: { label: "Pro", caption: "Sharp runs. Smarter saves.", cpuSpeed: 3.45, cpuShotRange: 470, cpuAim: 38, goalieSpeed: 2.45, goalieRead: 0.07, goalieReach: 3 },
  legend: { label: "Legend", caption: "Read the play. Beat the wall.", cpuSpeed: 4.05, cpuShotRange: 555, cpuAim: 15, goalieSpeed: 3.2, goalieRead: 0.13, goalieReach: 7 },
}

interface Vec2 { x: number; y: number }

function len(v: Vec2) { return Math.sqrt(v.x ** 2 + v.y ** 2) }
function norm(v: Vec2): Vec2 {
  const m = len(v); return m === 0 ? { x: 1, y: 0 } : { x: v.x / m, y: v.y / m }
}
function dist(a: Vec2, b: Vec2) { return Math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2) }

const FIELD = {
  x: 42, y: 30,
  w: W - 84, h: H - 60,
}
const GOAL_Y = H / 2 - GOAL_H / 2
const GOALIE_MIN_Y = GOAL_Y + GOALIE_R
const GOALIE_MAX_Y = GOAL_Y + GOAL_H - GOALIE_R

type PlayerState = {
  pos: Vec2
  vel: Vec2
  dir: Vec2
  hasBall: boolean
  kickCooldown: number
  slideFrames: number
  slideCooldown: number
}

type GoalieState = { pos: Vec2; vel: Vec2 }

type GameState = {
  p1: PlayerState
  p2: PlayerState
  blueTeam: PlayerState[]
  redTeam: PlayerState[]
  goalieL: GoalieState
  goalieR: GoalieState
  ball: { pos: Vec2; vel: Vec2 }
  score: [number, number]
  celebrating: number
  celebrateMsg: string
  switchCooldown: number
}

function makePlayer(x: number, y: number): PlayerState {
  return {
    pos: { x, y },
    vel: { x: 0, y: 0 },
    dir: { x: 1, y: 0 },
    hasBall: false,
    kickCooldown: 0,
    slideFrames: 0,
    slideCooldown: 0,
  }
}

function makeGoalie(x: number): GoalieState {
  return { pos: { x, y: H / 2 }, vel: { x: 0, y: 0 } }
}

function makeFormation(side: "blue" | "red"): PlayerState[] {
  const x = side === "blue" ? [0.18, 0.31, 0.44] : [0.82, 0.69, 0.56]
  const rows = [0.2, 0.38, 0.62, 0.8, 0.3, 0.7, 0.5, 0.16, 0.84]
  return rows.map((y, index) => makePlayer(W * x[index % 3], H * y))
}

function initState(format: MatchFormat = "1v1"): GameState {
  return {
    p1: makePlayer(W * 0.25, H / 2),
    p2: makePlayer(W * 0.75, H / 2),
    blueTeam: format === "11v11" ? makeFormation("blue") : [],
    redTeam: format === "11v11" ? makeFormation("red") : [],
    goalieL: makeGoalie(FIELD.x + GOALIE_R + 2),
    goalieR: makeGoalie(FIELD.x + FIELD.w - GOALIE_R - 2),
    ball: { pos: { x: W / 2, y: H / 2 }, vel: { x: 0, y: 0 } },
    score: [0, 0],
    celebrating: 0,
    celebrateMsg: "",
    switchCooldown: 0,
  }
}

function lighten(hex: string): string {
  const r = parseInt(hex.slice(1, 3), 16)
  const g = parseInt(hex.slice(3, 5), 16)
  const b = parseInt(hex.slice(5, 7), 16)
  const f = 1.6
  return `rgb(${Math.min(255, r * f)},${Math.min(255, g * f)},${Math.min(255, b * f)})`
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("home")
  const [selectedMode, setSelectedMode] = useState<"1p" | "2p">("1p")
  const [difficulty, setDifficulty] = useState<Difficulty>("pro")
  const [matchFormat, setMatchFormat] = useState<MatchFormat>("1v1")

  if (screen === "home") {
    return (
      <HomeScreen
        selectedMode={selectedMode}
        onSelectMode={setSelectedMode}
        difficulty={difficulty}
        onSelectDifficulty={setDifficulty}
        matchFormat={matchFormat}
        onSelectFormat={setMatchFormat}
        onLaunch={() => setScreen("game")}
        onPlay={() => setScreen("game")}
      />
    )
  }

  return <Game initialMode={selectedMode} difficulty={difficulty} matchFormat={matchFormat} onHome={() => setScreen("home")} />
}

function HomeScreen({
  selectedMode,
  onSelectMode,
  difficulty,
  onSelectDifficulty,
  matchFormat,
  onSelectFormat,
  onLaunch,
  onPlay,
}: {
  selectedMode: "1p" | "2p"
  onSelectMode: (m: "1p" | "2p") => void
  difficulty: Difficulty
  onSelectDifficulty: (d: Difficulty) => void
  matchFormat: MatchFormat
  onSelectFormat: (format: MatchFormat) => void
  onLaunch: () => void
  onPlay: () => void
}) {
  return (
    <div
      className="size-full flex items-center justify-center"
      style={{ background: "#0a1628", fontFamily: "'Barlow Condensed', sans-serif", userSelect: "none" }}
    >
      {/* Background field lines decoration */}
      <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%", opacity: 0.06 }} viewBox="0 0 800 500" preserveAspectRatio="xMidYMid slice">
        <rect x="60" y="40" width="680" height="420" fill="none" stroke="white" strokeWidth="2"/>
        <line x1="400" y1="40" x2="400" y2="460" stroke="white" strokeWidth="2"/>
        <circle cx="400" cy="250" r="80" fill="none" stroke="white" strokeWidth="2"/>
        <rect x="60" y="145" width="110" height="210" fill="none" stroke="white" strokeWidth="2"/>
        <rect x="630" y="145" width="110" height="210" fill="none" stroke="white" strokeWidth="2"/>
      </svg>

      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 0, position: "relative" }}>
        {/* Badge */}
        <div style={{
          background: "rgba(255,255,255,0.06)",
          border: "1px solid rgba(255,255,255,0.12)",
          borderRadius: 20,
          padding: "4px 14px",
          color: "rgba(255,255,255,0.4)",
          fontSize: 11,
          letterSpacing: "0.2em",
          textTransform: "uppercase",
          marginBottom: 24,
        }}>
          Game Day
        </div>

        <div style={{ width: 336, marginBottom: 20 }}>
          <div style={{ color: "rgba(255,255,255,0.45)", fontSize: 11, letterSpacing: "0.16em", textTransform: "uppercase", marginBottom: 8 }}>Match format</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
            {(["1v1", "11v11"] as MatchFormat[]).map(format => (
              <button key={format} onClick={() => onSelectFormat(format)} style={{ border: matchFormat === format ? "1px solid rgba(255,215,64,0.8)" : "1px solid rgba(255,255,255,0.1)", background: matchFormat === format ? "rgba(255,215,64,0.12)" : "rgba(255,255,255,0.035)", color: matchFormat === format ? "#ffe082" : "rgba(255,255,255,0.55)", borderRadius: 8, padding: "10px", cursor: "pointer", fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: 15, letterSpacing: "0.1em" }}>
                {format === "1v1" ? "DUEL · 1v1" : "FULL XI · 11v11"}
              </button>
            ))}
          </div>
        </div>

        <PartyPanel onLaunch={onLaunch} />

        {selectedMode === "1p" && (
          <div style={{ width: 496, marginTop: -16, marginBottom: 30 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 10 }}>
              <span style={{ color: "rgba(255,255,255,0.45)", fontSize: 11, letterSpacing: "0.16em", textTransform: "uppercase" }}>AI Challenge</span>
              <span style={{ color: "rgba(79,195,247,0.72)", fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase" }}>CPU + Rival GK</span>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 8 }}>
              {(Object.keys(DIFFICULTIES) as Difficulty[]).map(level => {
                const active = difficulty === level
                const settings = DIFFICULTIES[level]
                return (
                  <button key={level} onClick={() => onSelectDifficulty(level)} style={{
                    borderRadius: 8, padding: "11px 10px", cursor: "pointer", textAlign: "left",
                    border: active ? "1px solid rgba(79,195,247,0.8)" : "1px solid rgba(255,255,255,0.1)",
                    background: active ? "rgba(79,195,247,0.16)" : "rgba(255,255,255,0.035)",
                    color: active ? "#dff6ff" : "rgba(255,255,255,0.55)", transition: "all 0.15s",
                    fontFamily: "'Barlow Condensed', sans-serif",
                  }}>
                    <div style={{ fontWeight: 700, fontSize: 15, letterSpacing: "0.1em", textTransform: "uppercase" }}>{settings.label}</div>
                    <div style={{ marginTop: 3, fontSize: 10, lineHeight: 1.15, letterSpacing: "0.04em", color: active ? "rgba(223,246,255,0.7)" : "rgba(255,255,255,0.28)" }}>{settings.caption}</div>
                  </button>
                )
              })}
            </div>
          </div>
        )}

        {/* Title */}
        <div style={{ textAlign: "center", marginBottom: 48 }}>
          <div style={{
            fontSize: 88,
            fontWeight: 700,
            letterSpacing: "-0.02em",
            lineHeight: 1,
            color: "white",
            textShadow: "0 0 80px rgba(79,195,247,0.35)",
          }}>
            ⚽ GAME DAY
          </div>
          <div style={{
            fontSize: 16,
            color: "rgba(255,255,255,0.35)",
            letterSpacing: "0.18em",
            textTransform: "uppercase",
            marginTop: 10,
          }}>
            Choose your mode and play
          </div>
        </div>

        {/* Mode select */}
        <div style={{ display: "flex", gap: 16, marginBottom: 40 }}>
          {(["1p", "2p"] as const).map(m => (
            <button
              key={m}
              onClick={() => onSelectMode(m)}
              style={{
                width: 160,
                padding: "20px 0",
                borderRadius: 12,
                border: selectedMode === m
                  ? `2px solid ${m === "1p" ? "#4fc3f7" : "#aed581"}`
                  : "2px solid rgba(255,255,255,0.1)",
                background: selectedMode === m
                  ? m === "1p" ? "rgba(79,195,247,0.12)" : "rgba(174,213,129,0.12)"
                  : "rgba(255,255,255,0.04)",
                cursor: "pointer",
                transition: "all 0.15s",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: 8,
              }}
            >
              <div style={{ fontSize: 32 }}>{m === "1p" ? "🤖" : "👥"}</div>
              <div style={{
                fontSize: 18,
                fontWeight: 700,
                letterSpacing: "0.08em",
                color: selectedMode === m
                  ? m === "1p" ? "#4fc3f7" : "#aed581"
                  : "rgba(255,255,255,0.5)",
              }}>
                {m === "1p" ? "1 PLAYER" : "2 PLAYERS"}
              </div>
              <div style={{ fontSize: 12, color: "rgba(255,255,255,0.3)", letterSpacing: "0.05em" }}>
                {m === "1p" ? "vs CPU" : "Local co-op"}
              </div>
            </button>
          ))}
        </div>

        {/* Play button */}
        <button
          onClick={onPlay}
          style={{
            background: "linear-gradient(135deg, #4fc3f7, #0288d1)",
            color: "white",
            border: "none",
            borderRadius: 12,
            padding: "18px 72px",
            fontSize: 28,
            fontWeight: 700,
            letterSpacing: "0.12em",
            textTransform: "uppercase",
            cursor: "pointer",
            boxShadow: "0 8px 40px rgba(79,195,247,0.35)",
            transition: "transform 0.1s, box-shadow 0.1s",
            fontFamily: "'Barlow Condensed', sans-serif",
          }}
          onMouseEnter={e => {
            (e.currentTarget as HTMLButtonElement).style.transform = "scale(1.04)"
            ;(e.currentTarget as HTMLButtonElement).style.boxShadow = "0 12px 50px rgba(79,195,247,0.5)"
          }}
          onMouseLeave={e => {
            (e.currentTarget as HTMLButtonElement).style.transform = "scale(1)"
            ;(e.currentTarget as HTMLButtonElement).style.boxShadow = "0 8px 40px rgba(79,195,247,0.35)"
          }}
        >
          ▶ PLAY
        </button>

        {/* Controls reference */}
        <div style={{ marginTop: 40, display: "flex", gap: 40, color: "rgba(255,255,255,0.25)", fontSize: 12, letterSpacing: "0.08em" }}>
            <div>
              <div style={{ color: "rgba(255,255,255,0.4)", fontWeight: 700, marginBottom: 4 }}>P1</div>
              <div>WASD — Move</div>
              <div>Space — Shoot</div>
              <div>F — Slide tackle</div>
              {matchFormat === "11v11" && <div>Tab — Switch teammate</div>}
          </div>
          {selectedMode === "2p" && (
            <div>
              <div style={{ color: "rgba(255,255,255,0.4)", fontWeight: 700, marginBottom: 4 }}>P2</div>
              <div>Arrows — Move</div>
              <div>Enter — Shoot</div>
              <div>/ — Slide tackle</div>
            </div>
          )}
          <div>
            <div style={{ color: "rgba(255,255,255,0.4)", fontWeight: 700, marginBottom: 4 }}>Game</div>
            <div>P — Pause</div>
            <div>Run into ball to dribble</div>
          </div>
        </div>
      </div>
    </div>
  )
}

function PartyPanel({ onLaunch }: { onLaunch: () => void }) {
  const [name, setName] = useState("Player")
  const [joinCode, setJoinCode] = useState("")
  const [party, setParty] = useState<Party | null>(null)
  const [playerId] = useState(() => {
    const stored = localStorage.getItem("game-day-player-id")
    if (stored) return stored
    const id = crypto.randomUUID()
    localStorage.setItem("game-day-player-id", id)
    return id
  })
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState("")

  useEffect(() => {
    if (!party || party.started) return
    const heartbeat = async () => {
      try {
        const result = await partyRequest(`/parties/${party.code}/heartbeat`, "POST", { playerId })
        setParty(result.party)
      } catch (err) {
        setError(err instanceof Error ? err.message : "Connection lost.")
      }
    }
    const timer = window.setInterval(heartbeat, 5000)
    return () => window.clearInterval(timer)
  }, [party?.code, party?.started, playerId])

  const createParty = async () => {
    setBusy(true); setError("")
    try { setParty((await partyRequest("/parties", "POST", { playerId, name })).party) }
    catch (err) { setError(err instanceof Error ? err.message : "Could not create party.") }
    finally { setBusy(false) }
  }

  const joinParty = async () => {
    const code = joinCode.replace(/[^a-z0-9]/gi, "").toUpperCase()
    if (!code) { setError("Enter a party code first."); return }
    setBusy(true); setError("")
    try { setParty((await partyRequest(`/parties/${code}/join`, "POST", { playerId, name })).party) }
    catch (err) { setError(err instanceof Error ? err.message : "Could not join party.") }
    finally { setBusy(false) }
  }

  const startParty = async () => {
    if (!party) return
    setBusy(true); setError("")
    try {
      setParty((await partyRequest(`/parties/${party.code}/start`, "POST", { playerId })).party)
      onLaunch()
    } catch (err) { setError(err instanceof Error ? err.message : "Could not start party.") }
    finally { setBusy(false) }
  }

  if (party) {
    const isHost = party.hostId === playerId
    const ready = party.members.length === 2
    return (
      <div style={{ width: 496, marginBottom: 24, padding: "14px 16px", border: "1px solid rgba(255,215,64,0.3)", borderRadius: 12, background: "rgba(255,215,64,0.06)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div><div style={{ color: "#ffe082", fontSize: 11, letterSpacing: "0.16em", textTransform: "uppercase" }}>Cross-platform party</div><div style={{ color: "rgba(255,255,255,0.38)", fontSize: 11, marginTop: 3 }}>Share this code—your teammate can join from any device.</div></div>
          <div style={{ color: "white", fontSize: 23, fontWeight: 700, letterSpacing: "0.16em" }}>{party.code}</div>
        </div>
        <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
          {[0, 1].map(slot => {
            const member = party.members[slot]
            return <div key={slot} style={{ flex: 1, padding: "7px 10px", borderRadius: 6, background: member ? "rgba(79,195,247,0.12)" : "rgba(255,255,255,0.04)", color: member ? "#dff6ff" : "rgba(255,255,255,0.25)", fontSize: 12, letterSpacing: "0.08em" }}>{member ? `● ${member.name}` : "○ Waiting for teammate"}</div>
          })}
        </div>
        <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
          {isHost ? (
            <button onClick={startParty} disabled={!ready || busy} style={{ flex: 1, border: "none", borderRadius: 7, padding: "9px", background: ready ? "#4fc3f7" : "rgba(255,255,255,0.1)", color: ready ? "#062034" : "rgba(255,255,255,0.3)", cursor: ready ? "pointer" : "not-allowed", fontFamily: "'Barlow Condensed', sans-serif", fontSize: 14, fontWeight: 700, letterSpacing: "0.1em" }}>
              {busy ? "CONNECTING…" : ready ? "START PARTY MATCH" : "WAITING FOR PLAYER"}
            </button>
          ) : (
            <div style={{ flex: 1, textAlign: "center", padding: "9px", color: "rgba(255,255,255,0.45)", fontSize: 12, letterSpacing: "0.08em" }}>
              {party.started ? "HOST STARTED — PRESS PLAY" : "WAITING FOR HOST TO START"}
            </div>
          )}
          <button onClick={() => setParty(null)} style={{ border: "1px solid rgba(255,255,255,0.14)", borderRadius: 7, padding: "0 12px", background: "transparent", color: "rgba(255,255,255,0.5)", cursor: "pointer", fontFamily: "'Barlow Condensed', sans-serif" }}>LEAVE</button>
        </div>
        {error && <div style={{ color: "#ffab91", fontSize: 11, marginTop: 8 }}>{error}</div>}
      </div>
    )
  }

  return (
    <div style={{ width: 496, marginBottom: 24, padding: "14px 16px", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 12, background: "rgba(255,255,255,0.035)" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}><span style={{ color: "#ffe082", fontSize: 11, letterSpacing: "0.16em", textTransform: "uppercase" }}>Cross-platform party</span><span style={{ color: "rgba(255,255,255,0.32)", fontSize: 10, letterSpacing: "0.08em" }}>2 PLAYERS</span></div>
      <div style={{ display: "grid", gridTemplateColumns: "1.1fr 1fr 0.65fr", gap: 8 }}>
        <input value={name} maxLength={16} onChange={event => setName(event.target.value)} placeholder="Your name" style={{ minWidth: 0, border: "1px solid rgba(255,255,255,0.12)", borderRadius: 7, background: "rgba(0,0,0,0.18)", padding: "9px 10px", color: "white", outline: "none", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.06em" }} />
        <input value={joinCode} maxLength={6} onChange={event => setJoinCode(event.target.value.toUpperCase())} placeholder="PARTY CODE" style={{ minWidth: 0, border: "1px solid rgba(255,255,255,0.12)", borderRadius: 7, background: "rgba(0,0,0,0.18)", padding: "9px 10px", color: "white", outline: "none", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.12em" }} />
        <button onClick={joinParty} disabled={busy} style={{ border: "1px solid rgba(79,195,247,0.55)", borderRadius: 7, background: "rgba(79,195,247,0.14)", color: "#b9e8ff", cursor: "pointer", fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, letterSpacing: "0.08em" }}>JOIN</button>
      </div>
      <button onClick={createParty} disabled={busy} style={{ width: "100%", border: "none", borderRadius: 7, padding: "9px", marginTop: 8, background: "rgba(255,215,64,0.14)", color: "#ffe082", cursor: "pointer", fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, letterSpacing: "0.1em" }}>{busy ? "CONNECTING…" : "CREATE PARTY CODE"}</button>
      {error && <div style={{ color: "#ffab91", fontSize: 11, marginTop: 8 }}>{error}</div>}
    </div>
  )
}

function Game({ initialMode, difficulty, matchFormat, onHome }: { initialMode: "1p" | "2p"; difficulty: Difficulty; matchFormat: MatchFormat; onHome: () => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const stateRef = useRef<GameState>(initState(matchFormat))
  const keysRef = useRef<Set<string>>(new Set())
  const pausedRef = useRef(false)
  const modeRef = useRef<"1p" | "2p">(initialMode)
  const difficultyRef = useRef<Difficulty>(difficulty)
  const formatRef = useRef<MatchFormat>(matchFormat)
  const rafRef = useRef<number>(0)

  const [score, setScore] = useState<[number, number]>([0, 0])
  const [paused, setPaused] = useState(false)
  const [mode, setMode] = useState<"1p" | "2p">(initialMode)

  useEffect(() => {
    difficultyRef.current = difficulty
  }, [difficulty])

  useEffect(() => {
    formatRef.current = matchFormat
  }, [matchFormat])

  const togglePause = useCallback(() => {
    pausedRef.current = !pausedRef.current
    setPaused(p => !p)
  }, [])

  const resetGame = useCallback((keepScore: boolean) => {
    const prev = stateRef.current.score
    const s = initState(formatRef.current)
    if (keepScore) s.score = [...prev] as [number, number]
    stateRef.current = s
    setScore([...s.score] as [number, number])
  }, [])

  const switchMode = useCallback((m: "1p" | "2p") => {
    modeRef.current = m
    setMode(m)
    resetGame(false)
  }, [resetGame])

  useEffect(() => {
    const dn = (e: KeyboardEvent) => {
      keysRef.current.add(e.key.toLowerCase())
      if (e.key.toLowerCase() === "p") togglePause()
      if ([" ", "arrowup", "arrowdown", "arrowleft", "arrowright", "enter"].includes(e.key.toLowerCase()))
        e.preventDefault()
      if (e.key.toLowerCase() === "tab") e.preventDefault()
    }
    const up = (e: KeyboardEvent) => keysRef.current.delete(e.key.toLowerCase())
    window.addEventListener("keydown", dn)
    window.addEventListener("keyup", up)
    return () => { window.removeEventListener("keydown", dn); window.removeEventListener("keyup", up) }
  }, [togglePause])

  useEffect(() => {
    const canvas = canvasRef.current!
    const ctx = canvas.getContext("2d")!

    function drawField() {
      ctx.fillStyle = "#1a472a"
      ctx.fillRect(0, 0, W, H)

      const stripeW = FIELD.w / 8
      for (let i = 0; i < 8; i++) {
        ctx.fillStyle = i % 2 === 0 ? "#2d6a4f" : "#2e7d52"
        ctx.fillRect(FIELD.x + i * stripeW, FIELD.y, stripeW, FIELD.h)
      }

      ctx.strokeStyle = "rgba(255,255,255,0.85)"
      ctx.lineWidth = 2
      ctx.strokeRect(FIELD.x, FIELD.y, FIELD.w, FIELD.h)

      ctx.beginPath()
      ctx.moveTo(W / 2, FIELD.y)
      ctx.lineTo(W / 2, FIELD.y + FIELD.h)
      ctx.stroke()

      ctx.beginPath()
      ctx.arc(W / 2, H / 2, 60, 0, Math.PI * 2)
      ctx.stroke()
      ctx.beginPath()
      ctx.arc(W / 2, H / 2, 3, 0, Math.PI * 2)
      ctx.fillStyle = "white"
      ctx.fill()

      const penW = 110, penH = 220
      ctx.strokeRect(FIELD.x, H / 2 - penH / 2, penW, penH)
      ctx.strokeRect(FIELD.x + FIELD.w - penW, H / 2 - penH / 2, penW, penH)

      // Goals
      ctx.fillStyle = "rgba(255,255,255,0.12)"
      ctx.fillRect(FIELD.x - GOAL_DEPTH, GOAL_Y, GOAL_DEPTH, GOAL_H)
      ctx.strokeStyle = "rgba(255,255,255,0.9)"
      ctx.lineWidth = 3
      ctx.strokeRect(FIELD.x - GOAL_DEPTH, GOAL_Y, GOAL_DEPTH, GOAL_H)

      ctx.fillStyle = "rgba(255,255,255,0.12)"
      ctx.fillRect(FIELD.x + FIELD.w, GOAL_Y, GOAL_DEPTH, GOAL_H)
      ctx.strokeRect(FIELD.x + FIELD.w, GOAL_Y, GOAL_DEPTH, GOAL_H)
    }

    function drawPlayer(p: PlayerState, color: string, label: string) {
      const { pos, vel, dir, hasBall } = p
      const angle = len(vel) > 0.3 ? Math.atan2(vel.y, vel.x) : Math.atan2(dir.y, dir.x)
      const sliding = p.slideFrames > 0

      // Dribble glow
      if (hasBall) {
        ctx.beginPath()
        ctx.arc(pos.x, pos.y, PLAYER_R + 6, 0, Math.PI * 2)
        ctx.strokeStyle = "rgba(255,220,50,0.55)"
        ctx.lineWidth = 3
        ctx.stroke()
      }

      // Shadow
      ctx.beginPath()
      ctx.ellipse(pos.x + 3, pos.y + 4, PLAYER_R, PLAYER_R * 0.5, 0, 0, Math.PI * 2)
      ctx.fillStyle = "rgba(0,0,0,0.3)"
      ctx.fill()

      // Body
      ctx.beginPath()
      if (sliding) {
        ctx.ellipse(pos.x, pos.y, PLAYER_R + 5, PLAYER_R * 0.68, angle, 0, Math.PI * 2)
      } else {
        ctx.arc(pos.x, pos.y, PLAYER_R, 0, Math.PI * 2)
      }
      const grad = ctx.createRadialGradient(pos.x - 4, pos.y - 4, 2, pos.x, pos.y, PLAYER_R)
      grad.addColorStop(0, lighten(color))
      grad.addColorStop(1, color)
      ctx.fillStyle = grad
      ctx.fill()
      ctx.strokeStyle = "rgba(255,255,255,0.45)"
      ctx.lineWidth = 1.5
      ctx.stroke()

      // Direction dot
      const dx = pos.x + Math.cos(angle) * (PLAYER_R - 5)
      const dy = pos.y + Math.sin(angle) * (PLAYER_R - 5)
      ctx.beginPath()
      ctx.arc(dx, dy, 3, 0, Math.PI * 2)
      ctx.fillStyle = "rgba(255,255,255,0.8)"
      ctx.fill()

      // Label
      ctx.fillStyle = "white"
      ctx.font = "bold 10px 'Barlow Condensed', sans-serif"
      ctx.textAlign = "center"
      ctx.fillText(label, pos.x, pos.y + 3.5)
    }

    function drawGoalie(g: GoalieState, color: string) {
      const { pos } = g

      // Shadow
      ctx.beginPath()
      ctx.ellipse(pos.x + 3, pos.y + 4, GOALIE_R, GOALIE_R * 0.5, 0, 0, Math.PI * 2)
      ctx.fillStyle = "rgba(0,0,0,0.3)"
      ctx.fill()

      // Body — distinct goalkeeper color (yellow-green)
      ctx.beginPath()
      ctx.arc(pos.x, pos.y, GOALIE_R, 0, Math.PI * 2)
      const grad = ctx.createRadialGradient(pos.x - 3, pos.y - 3, 2, pos.x, pos.y, GOALIE_R)
      grad.addColorStop(0, lighten(color))
      grad.addColorStop(1, color)
      ctx.fillStyle = grad
      ctx.fill()
      ctx.strokeStyle = "rgba(255,255,255,0.5)"
      ctx.lineWidth = 2
      ctx.stroke()

      // GK label
      ctx.fillStyle = "white"
      ctx.font = "bold 9px 'Barlow Condensed', sans-serif"
      ctx.textAlign = "center"
      ctx.fillText("GK", pos.x, pos.y + 3.5)
    }

    function drawBall(pos: Vec2, vel: Vec2, owner: PlayerState | null) {
      if (owner) return // drawn relative to owner
      const spin = Date.now() * 0.006

      ctx.beginPath()
      ctx.ellipse(pos.x + 3, pos.y + 4, BALL_R, BALL_R * 0.5, 0, 0, Math.PI * 2)
      ctx.fillStyle = "rgba(0,0,0,0.35)"
      ctx.fill()

      ctx.beginPath()
      ctx.arc(pos.x, pos.y, BALL_R, 0, Math.PI * 2)
      const grad = ctx.createRadialGradient(pos.x - 3, pos.y - 3, 1, pos.x, pos.y, BALL_R)
      grad.addColorStop(0, "#fff")
      grad.addColorStop(0.5, "#e8e8e8")
      grad.addColorStop(1, "#999")
      ctx.fillStyle = grad
      ctx.fill()

      ctx.save()
      ctx.translate(pos.x, pos.y)
      ctx.rotate(spin * (len(vel) * 0.2 + 1))
      ctx.beginPath()
      for (let i = 0; i < 5; i++) {
        const a = (i / 5) * Math.PI * 2 - Math.PI / 2
        const r = BALL_R * 0.45
        i === 0 ? ctx.moveTo(Math.cos(a) * r, Math.sin(a) * r) : ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r)
      }
      ctx.closePath()
      ctx.fillStyle = "#222"
      ctx.fill()
      ctx.restore()
    }

    function drawDribbleBall(owner: PlayerState) {
      const angle = Math.atan2(owner.dir.y, owner.dir.x)
      const bx = owner.pos.x + Math.cos(angle) * DRIBBLE_DIST
      const by = owner.pos.y + Math.sin(angle) * DRIBBLE_DIST

      ctx.beginPath()
      ctx.ellipse(bx + 2, by + 3, BALL_R, BALL_R * 0.5, 0, 0, Math.PI * 2)
      ctx.fillStyle = "rgba(0,0,0,0.3)"
      ctx.fill()

      ctx.beginPath()
      ctx.arc(bx, by, BALL_R, 0, Math.PI * 2)
      const grad = ctx.createRadialGradient(bx - 3, by - 3, 1, bx, by, BALL_R)
      grad.addColorStop(0, "#fff")
      grad.addColorStop(0.5, "#e8e8e8")
      grad.addColorStop(1, "#999")
      ctx.fillStyle = grad
      ctx.fill()

      ctx.beginPath()
      for (let i = 0; i < 5; i++) {
        const a = (i / 5) * Math.PI * 2 - Math.PI / 2
        const r = BALL_R * 0.45
        const px = bx + Math.cos(a) * r
        const py = by + Math.sin(a) * r
        i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py)
      }
      ctx.closePath()
      ctx.fillStyle = "#222"
      ctx.fill()
    }

    function drawHUD(s: GameState, isPaused: boolean, gameMode: "1p" | "2p") {
      const sbW = 200, sbH = 52, sbX = W / 2 - sbW / 2, sbY = 6
      ctx.fillStyle = "rgba(0,0,0,0.75)"
      ctx.beginPath()
      ctx.roundRect(sbX, sbY, sbW, sbH, 10)
      ctx.fill()

      ctx.fillStyle = "#4fc3f7"
      ctx.font = "bold 28px 'Barlow Condensed', sans-serif"
      ctx.textAlign = "right"
      ctx.fillText(String(s.score[0]), W / 2 - 18, sbY + 36)

      ctx.fillStyle = "#ef9a9a"
      ctx.textAlign = "left"
      ctx.fillText(String(s.score[1]), W / 2 + 18, sbY + 36)

      ctx.fillStyle = "rgba(255,255,255,0.45)"
      ctx.font = "bold 24px 'Barlow Condensed', sans-serif"
      ctx.textAlign = "center"
      ctx.fillText(":", W / 2, sbY + 36)

      ctx.fillStyle = "#4fc3f7"
      ctx.font = "bold 10px 'Barlow Condensed', sans-serif"
      ctx.textAlign = "left"
      ctx.fillText("P1", sbX + 12, sbY + 15)

      ctx.fillStyle = "#ef9a9a"
      ctx.textAlign = "right"
      ctx.fillText(gameMode === "2p" ? "P2" : "CPU", sbX + sbW - 12, sbY + 15)

      // Controls hint bottom
      const hint = gameMode === "2p"
        ? "P1: WASD + Space + F  |  P2: Arrows + Enter + /  |  P: Pause"
        : "WASD + Space to shoot  |  F: Slide tackle  |  P: Pause"
      ctx.fillStyle = "rgba(255,255,255,0.3)"
      ctx.font = "11px 'Barlow Condensed', sans-serif"
      ctx.textAlign = "center"
      ctx.fillText(hint, W / 2, H - 10)

      if (isPaused) {
        ctx.fillStyle = "rgba(0,0,0,0.55)"
        ctx.fillRect(0, 0, W, H)
        ctx.fillStyle = "rgba(255,255,255,0.92)"
        ctx.font = "bold 56px 'Barlow Condensed', sans-serif"
        ctx.textAlign = "center"
        ctx.fillText("PAUSED", W / 2, H / 2 + 10)
        ctx.fillStyle = "rgba(255,255,255,0.4)"
        ctx.font = "18px 'Barlow Condensed', sans-serif"
        ctx.fillText("Press P or click Resume to continue", W / 2, H / 2 + 42)
      }
    }

    function drawCelebration(s: GameState) {
      if (s.celebrating <= 0) return
      const alpha = Math.min(1, s.celebrating / 30)
      ctx.fillStyle = `rgba(0,0,0,${alpha * 0.5})`
      ctx.fillRect(0, 0, W, H)

      ctx.save()
      ctx.translate(W / 2, H / 2)
      const sc = 1 + (1 - alpha) * 0.25
      ctx.scale(sc, sc)
      ctx.translate(-W / 2, -H / 2)
      ctx.fillStyle = `rgba(255,220,50,${alpha})`
      ctx.font = "bold 72px 'Barlow Condensed', sans-serif"
      ctx.textAlign = "center"
      ctx.shadowColor = "rgba(255,160,0,0.8)"
      ctx.shadowBlur = 30
      ctx.fillText("GOAL!", W / 2, H / 2 + 20)
      ctx.shadowBlur = 0
      ctx.fillStyle = `rgba(255,255,255,${alpha * 0.85})`
      ctx.font = "24px 'Barlow Condensed', sans-serif"
      ctx.fillText(s.celebrateMsg, W / 2, H / 2 + 55)
      ctx.restore()
    }

    function resolvePlayerBall(player: PlayerState, ball: { pos: Vec2; vel: Vec2 }) {
      const d = dist(player.pos, ball.pos)
      const minD = PLAYER_R + BALL_R
      if (d < minD && d > 0) {
        const nx = (ball.pos.x - player.pos.x) / d
        const ny = (ball.pos.y - player.pos.y) / d
        const overlap = minD - d
        ball.pos.x += nx * overlap
        ball.pos.y += ny * overlap

        const relVx = player.vel.x - ball.vel.x
        const relVy = player.vel.y - ball.vel.y
        const impact = relVx * nx + relVy * ny
        if (impact > 0) {
          ball.vel.x += nx * impact * KICK_FORCE * 0.12
          ball.vel.y += ny * impact * KICK_FORCE * 0.12
          player.vel.x -= nx * impact * 0.15
          player.vel.y -= ny * impact * 0.15
        }
      }
    }

    function resolvePlayerPlayer(a: PlayerState, b: PlayerState) {
      const d = dist(a.pos, b.pos)
      const minD = PLAYER_R * 2
      if (d < minD && d > 0) {
        const nx = (b.pos.x - a.pos.x) / d
        const ny = (b.pos.y - a.pos.y) / d
        const overlap = (minD - d) / 2
        a.pos.x -= nx * overlap
        a.pos.y -= ny * overlap
        b.pos.x += nx * overlap
        b.pos.y += ny * overlap
        const relVx = a.vel.x - b.vel.x
        const relVy = a.vel.y - b.vel.y
        const impact = relVx * nx + relVy * ny
        if (impact > 0) {
          a.vel.x -= nx * impact * 0.5
          a.vel.y -= ny * impact * 0.5
          b.vel.x += nx * impact * 0.5
          b.vel.y += ny * impact * 0.5
        }
      }
    }

    function getDribbleBallPos(owner: PlayerState): Vec2 {
      const angle = Math.atan2(owner.dir.y, owner.dir.x)
      return {
        x: owner.pos.x + Math.cos(angle) * DRIBBLE_DIST,
        y: owner.pos.y + Math.sin(angle) * DRIBBLE_DIST,
      }
    }

    function clampPlayer(p: PlayerState) {
      p.pos.x = Math.max(FIELD.x + PLAYER_R, Math.min(FIELD.x + FIELD.w - PLAYER_R, p.pos.x))
      p.pos.y = Math.max(FIELD.y + PLAYER_R, Math.min(FIELD.y + FIELD.h - PLAYER_R, p.pos.y))
    }

    function isInGoalY(y: number) { return y > GOAL_Y + BALL_R && y < GOAL_Y + GOAL_H - BALL_R }

    function tick() {
      const s = stateRef.current
      const keys = keysRef.current
      const isPaused = pausedRef.current
      const gameMode = modeRef.current
      const ai = DIFFICULTIES[difficultyRef.current]
      const fullMatch = formatRef.current === "11v11"

      if (s.celebrating > 0) {
        s.celebrating--
        if (s.celebrating === 0) {
          const prev = s.score
          const ns = initState(formatRef.current)
          ns.score = [...prev] as [number, number]
          stateRef.current = ns
        }
        ctx.clearRect(0, 0, W, H)
        drawField()
        const cur = stateRef.current
        const owner1 = cur.p1.hasBall ? cur.p1 : null
        const owner2 = cur.p2.hasBall ? cur.p2 : null
        if (owner1) drawDribbleBall(owner1)
        if (owner2) drawDribbleBall(owner2)
        drawGoalie(cur.goalieL, "#e65100")
        drawGoalie(cur.goalieR, "#e65100")
        drawPlayer(cur.p1, "#1565C0", "P1")
        drawPlayer(cur.p2, gameMode === "2p" ? "#558B2F" : "#c62828", gameMode === "2p" ? "P2" : "CPU")
        cur.blueTeam.forEach((player, i) => drawPlayer(player, "#1565C0", `B${i + 2}`))
        cur.redTeam.forEach((player, i) => drawPlayer(player, "#c62828", `R${i + 2}`))
        drawBall(cur.ball.pos, cur.ball.vel, owner1 || owner2)
        drawHUD(cur, false, gameMode)
        drawCelebration(s)
        rafRef.current = requestAnimationFrame(tick)
        return
      }

      if (isPaused) {
        ctx.clearRect(0, 0, W, H)
        drawField()
        const owner1 = s.p1.hasBall ? s.p1 : null
        const owner2 = s.p2.hasBall ? s.p2 : null
        if (owner1) drawDribbleBall(owner1)
        if (owner2) drawDribbleBall(owner2)
        drawGoalie(s.goalieL, "#e65100")
        drawGoalie(s.goalieR, "#e65100")
        drawPlayer(s.p1, "#1565C0", "P1")
        drawPlayer(s.p2, gameMode === "2p" ? "#558B2F" : "#c62828", gameMode === "2p" ? "P2" : "CPU")
        s.blueTeam.forEach((player, i) => drawPlayer(player, "#1565C0", `B${i + 2}`))
        s.redTeam.forEach((player, i) => drawPlayer(player, "#c62828", `R${i + 2}`))
        drawBall(s.ball.pos, s.ball.vel, owner1 || owner2)
        drawHUD(s, true, gameMode)
        rafRef.current = requestAnimationFrame(tick)
        return
      }

      const ball = s.ball

      // --- P1 INPUT ---
      let p1dx = 0, p1dy = 0
      if (keys.has("w")) p1dy -= 1
      if (keys.has("s")) p1dy += 1
      if (keys.has("a")) p1dx -= 1
      if (keys.has("d")) p1dx += 1
      if (p1dx !== 0 || p1dy !== 0) {
        const n = norm({ x: p1dx, y: p1dy })
        s.p1.vel.x += n.x * PLAYER_SPEED * 0.42
        s.p1.vel.y += n.y * PLAYER_SPEED * 0.42
        s.p1.dir = n
      }
      s.p1.vel.x *= FRICTION
      s.p1.vel.y *= FRICTION
      const p1spd = len(s.p1.vel)
      if (p1spd > PLAYER_SPEED) { s.p1.vel.x = s.p1.vel.x / p1spd * PLAYER_SPEED; s.p1.vel.y = s.p1.vel.y / p1spd * PLAYER_SPEED }
      s.p1.pos.x += s.p1.vel.x
      s.p1.pos.y += s.p1.vel.y
      s.p1.kickCooldown = Math.max(0, s.p1.kickCooldown - 1)
      s.p1.slideCooldown = Math.max(0, s.p1.slideCooldown - 1)
      s.p1.slideFrames = Math.max(0, s.p1.slideFrames - 1)
      clampPlayer(s.p1)

      // --- P2 / CPU ---
      if (gameMode === "2p") {
        let p2dx = 0, p2dy = 0
        if (keys.has("arrowup")) p2dy -= 1
        if (keys.has("arrowdown")) p2dy += 1
        if (keys.has("arrowleft")) p2dx -= 1
        if (keys.has("arrowright")) p2dx += 1
        if (p2dx !== 0 || p2dy !== 0) {
          const n = norm({ x: p2dx, y: p2dy })
          s.p2.vel.x += n.x * PLAYER_SPEED * 0.42
          s.p2.vel.y += n.y * PLAYER_SPEED * 0.42
          s.p2.dir = n
        }
        s.p2.vel.x *= FRICTION
        s.p2.vel.y *= FRICTION
        const p2spd = len(s.p2.vel)
        if (p2spd > PLAYER_SPEED) { s.p2.vel.x = s.p2.vel.x / p2spd * PLAYER_SPEED; s.p2.vel.y = s.p2.vel.y / p2spd * PLAYER_SPEED }
        s.p2.pos.x += s.p2.vel.x
        s.p2.pos.y += s.p2.vel.y
        s.p2.kickCooldown = Math.max(0, s.p2.kickCooldown - 1)
        s.p2.slideCooldown = Math.max(0, s.p2.slideCooldown - 1)
        s.p2.slideFrames = Math.max(0, s.p2.slideFrames - 1)
        clampPlayer(s.p2)
      } else {
        // CPU AI — challenge tiers increase anticipation, attacking range and shot placement.
        s.p2.kickCooldown = Math.max(0, s.p2.kickCooldown - 1)
        s.p2.slideCooldown = Math.max(0, s.p2.slideCooldown - 1)
        s.p2.slideFrames = Math.max(0, s.p2.slideFrames - 1)
        const ballPos = s.p2.hasBall ? getDribbleBallPos(s.p2) : ball.pos
        const bDist = dist(s.p2.pos, ballPos)
        const leadFrames = difficultyRef.current === "rookie" ? 2 : difficultyRef.current === "pro" ? 6 : 11
        const predictedBall = {
          x: Math.max(FIELD.x + BALL_R, Math.min(FIELD.x + FIELD.w - BALL_R, ballPos.x + ball.vel.x * leadFrames)),
          y: Math.max(FIELD.y + BALL_R, Math.min(FIELD.y + FIELD.h - BALL_R, ballPos.y + ball.vel.y * leadFrames)),
        }
        let targetX = predictedBall.x
        let targetY = predictedBall.y
        if (!s.p2.hasBall) {
          // Approach ball from behind (from right side, aim to get behind ball relative to left goal)
          if (bDist < 175) {
            const goalX = FIELD.x - GOAL_DEPTH / 2
            const toGoal = norm({ x: goalX - predictedBall.x, y: H / 2 - predictedBall.y })
            targetX = predictedBall.x - toGoal.x * 28
            targetY = predictedBall.y - toGoal.y * 28
          }
        } else {
          // Carry the ball toward the less-covered side of the left goal.
          targetX = FIELD.x - 10
          const leftGoalieY = s.goalieL.pos.y
          targetY = leftGoalieY < H / 2 ? GOAL_Y + GOAL_H - 22 : GOAL_Y + 22
        }
        const toTarget = norm({ x: targetX - s.p2.pos.x, y: targetY - s.p2.pos.y })
        s.p2.vel.x += toTarget.x * ai.cpuSpeed * 0.3
        s.p2.vel.y += toTarget.y * ai.cpuSpeed * 0.3
        const cpuSpd = len(s.p2.vel)
        if (cpuSpd > ai.cpuSpeed) { s.p2.vel.x = s.p2.vel.x / cpuSpd * ai.cpuSpeed; s.p2.vel.y = s.p2.vel.y / cpuSpd * ai.cpuSpeed }
        s.p2.vel.x *= FRICTION
        s.p2.vel.y *= FRICTION
        if (len({ x: toTarget.x, y: toTarget.y }) > 0.1) s.p2.dir = toTarget
        s.p2.pos.x += s.p2.vel.x
        s.p2.pos.y += s.p2.vel.y
        clampPlayer(s.p2)

        // CPU auto-shoot when has ball and close enough
        if (s.p2.hasBall && s.p2.kickCooldown === 0 && s.p2.pos.x < ai.cpuShotRange) {
          const openSide = s.goalieL.pos.y < H / 2 ? GOAL_Y + GOAL_H - 18 : GOAL_Y + 18
          const goalY = openSide + (Math.random() - 0.5) * ai.cpuAim
          const shootDir = norm({ x: FIELD.x - 20 - s.p2.pos.x, y: goalY - s.p2.pos.y })
          s.p2.hasBall = false
          ball.pos = getDribbleBallPos(s.p2)
          ball.vel.x = shootDir.x * SHOOT_SPEED
          ball.vel.y = shootDir.y * SHOOT_SPEED
          s.p2.kickCooldown = 25
        }
      }

      // --- TEAMMATE CPUs (Full XI) ---
      if (fullMatch) {
        const formationPoint = (side: "blue" | "red", index: number): Vec2 => {
          const columns = side === "blue" ? [0.18, 0.31, 0.44] : [0.82, 0.69, 0.56]
          const rows = [0.2, 0.38, 0.62, 0.8, 0.3, 0.7, 0.5, 0.16, 0.84]
          return { x: W * columns[index % 3], y: H * rows[index] }
        }
        const moveSupport = (player: PlayerState, side: "blue" | "red", index: number, chase: boolean) => {
          const home = formationPoint(side, index)
          const target = chase
            ? ball.pos
            : { x: home.x * 0.72 + ball.pos.x * 0.28, y: home.y * 0.72 + ball.pos.y * 0.28 }
          const direction = norm({ x: target.x - player.pos.x, y: target.y - player.pos.y })
          const speed = chase ? 2.85 : 2.05
          player.vel.x = player.vel.x * 0.78 + direction.x * speed * 0.22
          player.vel.y = player.vel.y * 0.78 + direction.y * speed * 0.22
          player.dir = direction
          player.pos.x += player.vel.x
          player.pos.y += player.vel.y
          clampPlayer(player)
        }
        const blueChaser = s.blueTeam.reduce((best, player, i, all) => dist(player.pos, ball.pos) < dist(all[best].pos, ball.pos) ? i : best, 0)
        const redChaser = s.redTeam.reduce((best, player, i, all) => dist(player.pos, ball.pos) < dist(all[best].pos, ball.pos) ? i : best, 0)
        s.blueTeam.forEach((player, i) => moveSupport(player, "blue", i, i === blueChaser))
        s.redTeam.forEach((player, i) => moveSupport(player, "red", i, i === redChaser))
      }

      // Tab rotates the human-controlled blue player with the next teammate.
      s.switchCooldown = Math.max(0, s.switchCooldown - 1)
      if (fullMatch && keys.has("tab") && s.switchCooldown === 0) {
        const next = s.blueTeam.shift()
        if (next) {
          s.blueTeam.push(s.p1)
          s.p1 = next
          s.switchCooldown = 18
        }
      }

      // --- SLIDE TACKLES ---
      // Slides are short bursts with a long recovery so timing matters.
      const startSlide = (player: PlayerState, key: string) => {
        if (!keys.has(key) || player.slideCooldown > 0 || player.slideFrames > 0) return
        player.slideFrames = SLIDE_FRAMES
        player.slideCooldown = SLIDE_COOLDOWN
        player.vel.x = player.dir.x * SLIDE_SPEED
        player.vel.y = player.dir.y * SLIDE_SPEED
      }
      startSlide(s.p1, "f")
      if (gameMode === "2p") startSlide(s.p2, "/")

      const resolveSlideTackle = (slider: PlayerState, carrier: PlayerState) => {
        if (slider.slideFrames <= 0 || !carrier.hasBall) return
        const heldBall = getDribbleBallPos(carrier)
        if (dist(slider.pos, heldBall) > PLAYER_R + BALL_R + 12) return
        carrier.hasBall = false
        carrier.kickCooldown = 24
        ball.pos = { ...heldBall }
        ball.vel = { x: slider.dir.x * SHOOT_SPEED * 0.85, y: slider.dir.y * SHOOT_SPEED * 0.85 }
      }
      resolveSlideTackle(s.p1, s.p2)
      resolveSlideTackle(s.p2, s.p1)

      // --- DRIBBLE LOGIC ---
      // P1 dribble pickup
      if (!s.p1.hasBall && !s.p2.hasBall && s.p1.kickCooldown === 0) {
        const d = dist(s.p1.pos, ball.pos)
        if (d < PLAYER_R + BALL_R + 6 && len(s.p1.vel) > 0.5) {
          s.p1.hasBall = true
          ball.vel = { x: 0, y: 0 }
        }
      }
      // P2 dribble pickup
      if (!s.p1.hasBall && !s.p2.hasBall && s.p2.kickCooldown === 0) {
        const d = dist(s.p2.pos, ball.pos)
        if (d < PLAYER_R + BALL_R + 6 && len(s.p2.vel) > 0.5) {
          s.p2.hasBall = true
          ball.vel = { x: 0, y: 0 }
        }
      }

      // If p1 has ball, sync ball position; tackle check
      if (s.p1.hasBall) {
        const bpos = getDribbleBallPos(s.p1)
        ball.pos.x = bpos.x
        ball.pos.y = bpos.y

        // Tackle: p2 touches dribble ball
        if (dist(s.p2.pos, bpos) < PLAYER_R + BALL_R + 2) {
          s.p1.hasBall = false
          s.p2.hasBall = true
          s.p1.kickCooldown = 20
          ball.vel = { x: 0, y: 0 }
        }

        // P1 shoot: Space
        if (keys.has(" ") && s.p1.kickCooldown === 0) {
          s.p1.hasBall = false
          ball.pos = { ...bpos }
          ball.vel.x = s.p1.dir.x * SHOOT_SPEED
          ball.vel.y = s.p1.dir.y * SHOOT_SPEED
          s.p1.kickCooldown = 20
        }
      }

      // If p2 has ball, sync ball position; tackle check
      if (s.p2.hasBall) {
        const bpos = getDribbleBallPos(s.p2)
        ball.pos.x = bpos.x
        ball.pos.y = bpos.y

        // Tackle: p1 touches dribble ball
        if (dist(s.p1.pos, bpos) < PLAYER_R + BALL_R + 2) {
          s.p2.hasBall = false
          s.p1.hasBall = true
          s.p2.kickCooldown = 20
          ball.vel = { x: 0, y: 0 }
        }

        // P2 shoot (2P only — cpu handles its own)
        if (gameMode === "2p" && (keys.has("enter") || keys.has("shift")) && s.p2.kickCooldown === 0) {
          s.p2.hasBall = false
          ball.pos = { ...bpos }
          ball.vel.x = s.p2.dir.x * SHOOT_SPEED
          ball.vel.y = s.p2.dir.y * SHOOT_SPEED
          s.p2.kickCooldown = 20
        }
      }

      // Ball physics (only when free)
      if (!s.p1.hasBall && !s.p2.hasBall) {
        ball.vel.x *= BALL_FRICTION
        ball.vel.y *= BALL_FRICTION
        ball.pos.x += ball.vel.x
        ball.pos.y += ball.vel.y

        // Wall collisions
        if (ball.pos.x - BALL_R < FIELD.x) {
          if (!isInGoalY(ball.pos.y)) { ball.pos.x = FIELD.x + BALL_R; ball.vel.x *= -0.7 }
          else if (ball.pos.x < FIELD.x - GOAL_DEPTH + BALL_R) { ball.pos.x = FIELD.x - GOAL_DEPTH + BALL_R; ball.vel.x *= -0.5 }
        }
        if (ball.pos.x + BALL_R > FIELD.x + FIELD.w) {
          if (!isInGoalY(ball.pos.y)) { ball.pos.x = FIELD.x + FIELD.w - BALL_R; ball.vel.x *= -0.7 }
          else if (ball.pos.x > FIELD.x + FIELD.w + GOAL_DEPTH - BALL_R) { ball.pos.x = FIELD.x + FIELD.w + GOAL_DEPTH - BALL_R; ball.vel.x *= -0.5 }
        }
        if (ball.pos.y - BALL_R < FIELD.y) { ball.pos.y = FIELD.y + BALL_R; ball.vel.y *= -0.7 }
        if (ball.pos.y + BALL_R > FIELD.y + FIELD.h) { ball.pos.y = FIELD.y + FIELD.h - BALL_R; ball.vel.y *= -0.7 }

        // Player-ball push (when no dribble)
        resolvePlayerBall(s.p1, ball)
        resolvePlayerBall(s.p2, ball)
        if (fullMatch) {
          s.blueTeam.forEach(player => resolvePlayerBall(player, ball))
          s.redTeam.forEach(player => resolvePlayerBall(player, ball))
        }
      }

      // Goal detection (ball or dribble ball)
      const checkGoal = (bx: number, by: number) => {
        if (isInGoalY(by)) {
          // Score as soon as the whole ball has crossed the goal line. The deeper net
          // remains visual space rather than demanding an unreachable extra roll.
          if (bx < FIELD.x - BALL_R) return "left"
          if (bx > FIELD.x + FIELD.w + BALL_R) return "right"
        }
        return null
      }
      const scored = checkGoal(ball.pos.x, ball.pos.y)
      if (scored && s.celebrating === 0) {
        if (scored === "left") { s.score[1]++; s.celebrateMsg = gameMode === "2p" ? "P2 scored!" : "CPU scored!" }
        else { s.score[0]++; s.celebrateMsg = gameMode === "2p" ? "P1 scored!" : "You scored!" }
        s.p1.hasBall = false
        s.p2.hasBall = false
        ball.vel = { x: 0, y: 0 }
        s.celebrating = 90
        setScore([...s.score] as [number, number])
      }

      resolvePlayerPlayer(s.p1, s.p2)

      // --- GOALIE AI ---
      function tickGoalie(g: GoalieState, targetX: number, isRival: boolean) {
        // Always snap to fixed X (goalies only move vertically)
        g.pos.x = targetX

        // The rival keeper reads the incoming ball further ahead on higher challenges.
        const owner = s.p1.hasBall ? s.p1 : s.p2.hasBall ? s.p2 : null
        const read = isRival && gameMode === "1p" ? ai.goalieRead : 0.1
        const ballY = owner
          ? owner.pos.y + owner.dir.y * (isRival && gameMode === "1p" ? 24 : 10)
          : ball.pos.y + ball.vel.y * read * 20
        const dy = ballY - g.pos.y
        const maxSpeed = isRival && gameMode === "1p" ? ai.goalieSpeed : GOALIE_SPEED
        const speed = Math.min(maxSpeed, Math.abs(dy) * (isRival && gameMode === "1p" ? 0.27 : 0.18))
        g.vel.y = Math.sign(dy) * speed
        g.pos.y += g.vel.y
        g.pos.y = Math.max(GOALIE_MIN_Y, Math.min(GOALIE_MAX_Y, g.pos.y))

        // Deflect free ball
        if (!s.p1.hasBall && !s.p2.hasBall) {
          const d = dist(g.pos, ball.pos)
          const minD = GOALIE_R + BALL_R + (isRival && gameMode === "1p" ? ai.goalieReach : 0)
          if (d < minD && d > 0) {
            const nx = (ball.pos.x - g.pos.x) / d
            const ny = (ball.pos.y - g.pos.y) / d
            ball.pos.x += nx * (minD - d)
            ball.pos.y += ny * (minD - d)
            const impact = (g.vel.x ?? 0) * nx + g.vel.y * ny - (ball.vel.x * nx + ball.vel.y * ny)
            if (impact < 0) {
              ball.vel.x -= nx * impact * 1.05
              ball.vel.y -= ny * impact * 1.05
            }
            // Always push ball away from goal
            ball.vel.x += nx * 1.55
          }
        }
      }

      const goalieRX = FIELD.x + FIELD.w - GOALIE_R - 2
      const goalieOX = FIELD.x + GOALIE_R + 2
      tickGoalie(s.goalieL, goalieOX, false)
      tickGoalie(s.goalieR, goalieRX, true)

      // Draw
      ctx.clearRect(0, 0, W, H)
      drawField()
      if (s.p1.hasBall) drawDribbleBall(s.p1)
      if (s.p2.hasBall) drawDribbleBall(s.p2)
      drawGoalie(s.goalieL, "#e65100")
      drawGoalie(s.goalieR, "#e65100")
      drawPlayer(s.p1, "#1565C0", "P1")
      drawPlayer(s.p2, gameMode === "2p" ? "#558B2F" : "#c62828", gameMode === "2p" ? "P2" : "CPU")
      s.blueTeam.forEach((player, i) => drawPlayer(player, "#1565C0", `B${i + 2}`))
      s.redTeam.forEach((player, i) => drawPlayer(player, "#c62828", `R${i + 2}`))
      if (!s.p1.hasBall && !s.p2.hasBall) drawBall(ball.pos, ball.vel, null)
      drawHUD(s, false, gameMode)
      drawCelebration(s)

      rafRef.current = requestAnimationFrame(tick)
    }

    rafRef.current = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(rafRef.current)
  }, [resetGame])

  const btnBase: React.CSSProperties = {
    border: "1px solid rgba(255,255,255,0.15)",
    padding: "7px 18px",
    borderRadius: 6,
    fontSize: 12,
    letterSpacing: "0.12em",
    textTransform: "uppercase" as const,
    cursor: "pointer",
    fontFamily: "'Barlow Condensed', sans-serif",
    fontWeight: 700,
    transition: "background 0.15s, color 0.15s",
  }

  const setVirtualKey = (key: string, pressed: boolean) => {
    if (pressed) keysRef.current.add(key)
    else keysRef.current.delete(key)
  }

  return (
    <div
      className="size-full flex items-center justify-center"
      style={{ background: "#0a1628", fontFamily: "'Barlow Condensed', sans-serif" }}
    >
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12, width: "min(100%, 1344px)", padding: "0 12px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", width: "100%" }}>
          {/* Mode switcher */}
          <div style={{ display: "flex", gap: 6 }}>
            <button
              onClick={() => switchMode("1p")}
              style={{
                ...btnBase,
                background: mode === "1p" ? "rgba(79,195,247,0.2)" : "rgba(255,255,255,0.05)",
                color: mode === "1p" ? "#4fc3f7" : "rgba(255,255,255,0.45)",
                borderColor: mode === "1p" ? "rgba(79,195,247,0.5)" : "rgba(255,255,255,0.1)",
              }}
            >
              1P vs CPU
            </button>
            <button
              onClick={() => switchMode("2p")}
              style={{
                ...btnBase,
                background: mode === "2p" ? "rgba(139,195,74,0.2)" : "rgba(255,255,255,0.05)",
                color: mode === "2p" ? "#aed581" : "rgba(255,255,255,0.45)",
                borderColor: mode === "2p" ? "rgba(139,195,74,0.5)" : "rgba(255,255,255,0.1)",
              }}
            >
              2 Player
            </button>
          </div>

          <div style={{ color: "rgba(255,255,255,0.35)", fontSize: 11, letterSpacing: "0.18em", textTransform: "uppercase" }}>
            Game Day · {matchFormat === "11v11" ? "Full XI" : "Duel"}{mode === "1p" ? ` · ${DIFFICULTIES[difficulty].label} AI` : ""}
          </div>

          {/* Controls */}
          <div style={{ display: "flex", gap: 6 }}>
            <button
              onClick={togglePause}
              style={{
                ...btnBase,
                background: paused ? "rgba(255,220,50,0.15)" : "rgba(255,255,255,0.07)",
                color: paused ? "#ffd740" : "rgba(255,255,255,0.55)",
                borderColor: paused ? "rgba(255,220,50,0.4)" : "rgba(255,255,255,0.12)",
                minWidth: 90,
              }}
            >
              {paused ? "▶ Resume" : "⏸ Pause"}
            </button>
            <button
              onClick={() => resetGame(false)}
              style={{
                ...btnBase,
                background: "rgba(255,255,255,0.05)",
                color: "rgba(255,255,255,0.45)",
              }}
            >
              Reset
            </button>
            <button
              onClick={onHome}
              style={{
                ...btnBase,
                background: "rgba(255,255,255,0.05)",
                color: "rgba(255,255,255,0.4)",
              }}
            >
              ⌂ Home
            </button>
          </div>
        </div>

        <canvas
          ref={canvasRef}
          width={W}
          height={H}
          style={{
            display: "block",
            width: "100%",
            height: "auto",
            borderRadius: 8,
            boxShadow: "0 0 60px rgba(0,200,80,0.12), 0 24px 60px rgba(0,0,0,0.7)",
            border: "1px solid rgba(255,255,255,0.07)",
          }}
        />

        <div className="touch-controls" aria-label="Touch controls">
          <div className="touch-dpad">
            {["w", "a", "s", "d"].map(key => (
              <button
                key={key}
                className={`touch-key touch-${key}`}
                onPointerDown={() => setVirtualKey(key, true)}
                onPointerUp={() => setVirtualKey(key, false)}
                onPointerLeave={() => setVirtualKey(key, false)}
                onPointerCancel={() => setVirtualKey(key, false)}
              >{key === "w" ? "▲" : key === "a" ? "◀" : key === "s" ? "▼" : "▶"}</button>
            ))}
          </div>
          <div className="touch-actions">
            <button className="touch-key touch-switch" onPointerDown={() => setVirtualKey("tab", true)} onPointerUp={() => setVirtualKey("tab", false)}>SWITCH</button>
            <button className="touch-key touch-slide" onPointerDown={() => setVirtualKey("f", true)} onPointerUp={() => setVirtualKey("f", false)}>SLIDE</button>
            <button className="touch-key touch-shoot" onPointerDown={() => setVirtualKey(" ", true)} onPointerUp={() => setVirtualKey(" ", false)}>SHOOT</button>
          </div>
        </div>
      </div>
    </div>
  )
}
